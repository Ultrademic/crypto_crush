import { Token, Position } from '@/types/game';
import { CRYPTO_TYPES, LEVELS } from '@/constants/cryptos';

export const generateId = () => Math.random().toString(36).substr(2, 9);

export const getRandomCrypto = () => CRYPTO_TYPES[Math.floor(Math.random() * CRYPTO_TYPES.length)];

export const findMatches = (board: Token[][]): Position[] => {
  const matches: Position[] = [];
  const size = board.length;

  // Horizontal matches
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size - 2; col++) {
      const type = board[row][col]?.type;
      if (type && board[row][col + 1]?.type === type && board[row][col + 2]?.type === type) {
        matches.push({ row, col }, { row, col: col + 1 }, { row, col: col + 2 });
        let k = col + 3;
        while (k < size && board[row][k]?.type === type) {
          matches.push({ row, col: k });
          k++;
        }
      }
    }
  }

  // Vertical matches
  for (let col = 0; col < size; col++) {
    for (let row = 0; row < size - 2; row++) {
      const type = board[row][col]?.type;
      if (type && board[row + 1]?.[col]?.type === type && board[row + 2]?.[col]?.type === type) {
        matches.push({ row, col }, { row: row + 1, col }, { row: row + 2, col });
        let k = row + 3;
        while (k < size && board[k]?.[col]?.type === type) {
          matches.push({ row: k, col });
          k++;
        }
      }
    }
  }

  return [...new Map(matches.map(m => [`${m.row}-${m.col}`, m])).values()];
};

export const applyGravity = (board: Token[][]): Token[][] => {
  const size = board.length;
  const newBoard = board.map(row => [...row]);

  for (let col = 0; col < size; col++) {
    let writeRow = size - 1;
    for (let row = size - 1; row >= 0; row--) {
      if (newBoard[row][col] && !newBoard[row][col].isMatched) {
        if (row !== writeRow) {
          newBoard[writeRow][col] = { ...newBoard[row][col], row: writeRow };
          newBoard[row][col] = null as any;
        }
        writeRow--;
      }
    }
    for (let row = writeRow; row >= 0; row--) {
      newBoard[row][col] = {
        id: generateId(),
        type: getRandomCrypto(),
        row,
        col,
        isMatched: false,
      };
    }
  }
  return newBoard;
};

export const isAdjacent = (pos1: Position, pos2: Position): boolean => {
  const rowDiff = Math.abs(pos1.row - pos2.row);
  const colDiff = Math.abs(pos1.col - pos2.col);
  return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
};
