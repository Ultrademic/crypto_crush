import React, { useState } from 'react';
import { Token, GameState } from '@/types/game';
import { CRYPTO_TYPES, LEVELS } from '@/constants/cryptos';
import { SoundProvider } from '@/contexts/SoundContext';
import TickerWall from './game/TickerWall';
import GameHeader from './game/GameHeader';
import GameBoard from './game/GameBoard';
import GamePanel from './game/GamePanel';
import CryptoLegend from './game/CryptoLegend';
import LevelSelect from './game/LevelSelect';
import GameOverlay from './game/GameOverlay';
import HowToPlay from './game/HowToPlay';
import ComboIndicator from './game/ComboIndicator';
import GameFooter from './game/GameFooter';
import ScorePopup from './game/ScorePopup';

const BG_IMAGE = 'https://d64gsuwffb70l.cloudfront.net/692f51cd02b0243a957097ee_1764708873462_0fbe2f6a.webp';

const generateId = () => Math.random().toString(36).substr(2, 9);
const getRandomCrypto = () => CRYPTO_TYPES[Math.floor(Math.random() * CRYPTO_TYPES.length)];

const createBoard = (size: number): Token[][] => {
  const board: Token[][] = [];
  for (let row = 0; row < size; row++) {
    board[row] = [];
    for (let col = 0; col < size; col++) {
      let type = getRandomCrypto();
      while (
        (col >= 2 && board[row][col - 1]?.type === type && board[row][col - 2]?.type === type) ||
        (row >= 2 && board[row - 1]?.[col]?.type === type && board[row - 2]?.[col]?.type === type)
      ) {
        type = getRandomCrypto();
      }
      board[row][col] = { id: generateId(), type, row, col, isMatched: false };
    }
  }
  return board;
};

const AppLayout: React.FC = () => {
  const [showLevels, setShowLevels] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [gameState, setGameState] = useState<GameState>(() => ({
    board: createBoard(8),
    score: 0,
    moves: LEVELS[0].moves,
    level: 1,
    combo: 1,
    isAnimating: false,
    gameOver: false,
    levelComplete: false,
    highScore: parseInt(localStorage.getItem('cryptoCrushHighScore') || '0'),
  }));

  const initGame = (levelId: number = 1) => {
    const level = LEVELS[levelId - 1];
    setGameState(prev => ({
      ...prev,
      board: createBoard(level.gridSize),
      score: 0,
      moves: level.moves,
      level: levelId,
      combo: 1,
      isAnimating: false,
      gameOver: false,
      levelComplete: false,
    }));
    setShowLevels(false);
  };

  const handleNextLevel = () => {
    if (gameState.level < LEVELS.length) initGame(gameState.level + 1);
  };

  return (
    <SoundProvider>
      <div className="min-h-screen bg-gray-950 text-white" style={{ backgroundImage: `url(${BG_IMAGE})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundAttachment: 'fixed' }}>
        <div className="min-h-screen bg-gray-950/90 backdrop-blur-sm flex flex-col">
          <TickerWall />
          <div className="container mx-auto px-4 pb-8 flex-1">
            <GameHeader onHowToPlay={() => setShowHelp(true)} />
            <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 items-center lg:items-start justify-center">
              <div className="hidden lg:block order-1"><CryptoLegend /></div>
              <div className="order-2"><GameBoard gameState={gameState} setGameState={setGameState} /></div>
              <div className="order-3 w-full max-w-xs"><GamePanel gameState={gameState} onNewGame={() => initGame(gameState.level)} onLevelSelect={() => setShowLevels(true)} /></div>
            </div>
            <div className="lg:hidden mt-4 flex justify-center"><CryptoLegend /></div>
          </div>
          <GameFooter />
          <ComboIndicator combo={gameState.combo} />
          <ScorePopup score={gameState.score} combo={gameState.combo} />
          {showLevels && <LevelSelect currentLevel={gameState.level} highScore={gameState.highScore} onSelectLevel={initGame} onClose={() => setShowLevels(false)} />}
          {showHelp && <HowToPlay onClose={() => setShowHelp(false)} />}
          <GameOverlay gameState={gameState} onNewGame={() => initGame(gameState.level)} onNextLevel={handleNextLevel} />
        </div>
      </div>
    </SoundProvider>
  );
};

export default AppLayout;
