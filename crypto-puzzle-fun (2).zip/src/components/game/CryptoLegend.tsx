import React from 'react';
import { CRYPTO_CONFIG, CRYPTO_TYPES } from '@/constants/cryptos';

const CryptoLegend: React.FC = () => {
  return (
    <div className="bg-gray-900/90 backdrop-blur-sm rounded-2xl p-4 border border-cyan-500/30 w-full max-w-xs lg:max-w-none">
      <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
        Tokens
      </h3>
      <div className="grid grid-cols-3 lg:grid-cols-2 gap-2">
        {CRYPTO_TYPES.map(type => {
          const config = CRYPTO_CONFIG[type];
          return (
            <div key={type} className="flex items-center gap-2 bg-gray-800/30 rounded-lg p-1.5 hover:bg-gray-800/50 transition-colors">
              <div 
                className="w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold shrink-0"
                style={{ 
                  background: `linear-gradient(135deg, ${config.color}ee, ${config.color}99)`,
                  color: type === 'ADA' || type === 'XRP' ? '#fff' : '#1a1a2e',
                  boxShadow: `0 0 8px ${config.glow}40`
                }}
              >
                {config.symbol}
              </div>
              <span className="text-xs text-gray-300 truncate">{config.name}</span>
            </div>
          );
        })}
      </div>
      <div className="mt-3 pt-3 border-t border-gray-800 text-xs text-gray-500">
        Match 3+ identical tokens to score!
      </div>
    </div>
  );
};

export default CryptoLegend;
