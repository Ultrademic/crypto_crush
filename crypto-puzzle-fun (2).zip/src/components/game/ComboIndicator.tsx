import React, { useEffect, useState } from 'react';

interface Props {
  combo: number;
}

const ComboIndicator: React.FC<Props> = ({ combo }) => {
  const [show, setShow] = useState(false);
  const [displayCombo, setDisplayCombo] = useState(1);

  useEffect(() => {
    if (combo > 1) {
      setDisplayCombo(combo);
      setShow(true);
      const timer = setTimeout(() => setShow(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [combo]);

  if (!show || displayCombo <= 1) return null;

  const colors = [
    'from-yellow-400 to-orange-500',
    'from-orange-500 to-red-500',
    'from-red-500 to-pink-500',
    'from-pink-500 to-purple-500',
    'from-purple-500 to-cyan-500',
  ];

  const colorIndex = Math.min(displayCombo - 2, colors.length - 1);

  return (
    <div className="fixed inset-0 pointer-events-none flex items-center justify-center z-40">
      <div className={`
        text-6xl md:text-8xl font-black
        bg-gradient-to-r ${colors[colorIndex]} bg-clip-text text-transparent
        animate-bounce drop-shadow-2xl
      `}>
        {displayCombo}x COMBO!
      </div>
    </div>
  );
};

export default ComboIndicator;
