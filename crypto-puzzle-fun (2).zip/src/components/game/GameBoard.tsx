import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Token, Position, GameState } from '@/types/game';
import { findMatches, applyGravity, isAdjacent } from '@/utils/gameUtils';
import { LEVELS, CRYPTO_TYPES } from '@/constants/cryptos';
import { useSound } from '@/contexts/SoundContext';
import CryptoToken from './CryptoToken';

const generateId = () => Math.random().toString(36).substr(2, 9);
const getRandomCrypto = () => CRYPTO_TYPES[Math.floor(Math.random() * CRYPTO_TYPES.length)];

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

const GameBoard: React.FC<Props> = ({ gameState, setGameState }) => {
  const [selected, setSelected] = useState<Position | null>(null);
  const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 800);
  const size = gameState.board.length;
  const { playMatch, playCombo, playClick } = useSound();

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const cellSize = useMemo(() => {
    const maxWidth = windowWidth < 640 ? windowWidth - 32 : 400;
    return Math.floor(maxWidth / size);
  }, [windowWidth, size]);

  const processMatches = useCallback(() => {
    const matches = findMatches(gameState.board);
    if (matches.length === 0) {
      setGameState(prev => ({ ...prev, combo: 1, isAnimating: false }));
      return;
    }

    // Play match sound
    playMatch();
    
    // Play combo sound if combo > 1
    if (gameState.combo > 1) {
      setTimeout(() => playCombo(gameState.combo), 150);
    }

    const points = matches.length * 50 * gameState.combo;
    const newBoard = gameState.board.map(row => row.map(t => 
      matches.some(m => m.row === t.row && m.col === t.col) ? { ...t, isMatched: true } : t
    ));

    setGameState(prev => ({ ...prev, board: newBoard, score: prev.score + points }));

    setTimeout(() => {
      const filledBoard = newBoard.map(row => [...row]);
      for (let col = 0; col < size; col++) {
        let writeRow = size - 1;
        for (let row = size - 1; row >= 0; row--) {
          if (filledBoard[row][col] && !filledBoard[row][col].isMatched) {
            if (row !== writeRow) {
              filledBoard[writeRow][col] = { ...filledBoard[row][col], row: writeRow };
              filledBoard[row][col] = null as any;
            }
            writeRow--;
          }
        }
        for (let row = writeRow; row >= 0; row--) {
          filledBoard[row][col] = { id: generateId(), type: getRandomCrypto(), row, col, isMatched: false };
        }
      }
      setGameState(prev => ({ ...prev, board: filledBoard, combo: 1, isAnimating: false }));
    }, 300);
  }, [gameState.board, gameState.combo, setGameState, size, playMatch, playCombo]);


  const handleSwap = useCallback((pos1: Position, pos2: Position) => {
    if (gameState.moves <= 0 || gameState.isAnimating) return;

    const newBoard = gameState.board.map(row => [...row]);
    const temp = { ...newBoard[pos1.row][pos1.col] };
    newBoard[pos1.row][pos1.col] = { ...newBoard[pos2.row][pos2.col], row: pos1.row, col: pos1.col };
    newBoard[pos2.row][pos2.col] = { ...temp, row: pos2.row, col: pos2.col };

    const matches = findMatches(newBoard);
    if (matches.length > 0) {
      setGameState(prev => ({ ...prev, board: newBoard, moves: prev.moves - 1, isAnimating: true }));
      setTimeout(() => processMatches(), 200);
    }
    setSelected(null);
  }, [gameState.board, gameState.moves, gameState.isAnimating, setGameState, processMatches]);

  const handleClick = (row: number, col: number) => {
    if (gameState.isAnimating) return;
    playClick();
    const pos = { row, col };
    if (selected) {
      if (isAdjacent(selected, pos)) handleSwap(selected, pos);
      else setSelected(pos);
    } else setSelected(pos);
  };

  useEffect(() => {
    const level = LEVELS[gameState.level - 1];
    if (gameState.score >= level.targetScore && !gameState.levelComplete) {
      const newHigh = Math.max(gameState.score, gameState.highScore);
      localStorage.setItem('cryptoCrushHighScore', newHigh.toString());
      setGameState(prev => ({ ...prev, levelComplete: true, highScore: newHigh }));
    } else if (gameState.moves <= 0 && !gameState.isAnimating && !gameState.levelComplete) {
      setGameState(prev => ({ ...prev, gameOver: true }));
    }
  }, [gameState.score, gameState.moves, gameState.isAnimating, gameState.level, gameState.levelComplete, gameState.highScore, setGameState]);

  return (
    <div className="relative bg-gray-900/80 rounded-2xl p-2 border border-cyan-500/30 shadow-2xl backdrop-blur-sm"
      style={{ width: size * cellSize + 16, height: size * cellSize + 16 }}>
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-purple-500/5 rounded-2xl" />
      <div className="relative" style={{ width: size * cellSize, height: size * cellSize }}>
        {gameState.board.flat().map(token => (
          <CryptoToken key={token.id} token={token} isSelected={selected?.row === token.row && selected?.col === token.col}
            onClick={() => handleClick(token.row, token.col)} size={cellSize} />
        ))}
      </div>
    </div>
  );
};

export default GameBoard;
