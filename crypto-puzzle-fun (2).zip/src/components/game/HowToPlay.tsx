import React from 'react';
import { CRYPTO_CONFIG } from '@/constants/cryptos';
import { useSound } from '@/contexts/SoundContext';

interface Props {
  onClose: () => void;
}

const HowToPlay: React.FC<Props> = ({ onClose }) => {
  const { playClick } = useSound();

  const handleClose = () => {
    playClick();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={handleClose}>
      <div className="bg-gray-900 rounded-2xl p-6 max-w-lg w-full border border-cyan-500/30 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
            How to Play
          </h2>
          <button onClick={handleClose} className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center text-gray-400 hover:text-white transition">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="space-y-4 text-gray-300 text-sm">
          <div className="flex gap-3 items-start">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-cyan-500/30 to-purple-500/30 flex items-center justify-center text-cyan-400 font-bold shrink-0 text-sm border border-cyan-500/30">1</div>
            <p><strong className="text-white">Match 3 or more</strong> identical crypto tokens in a row or column to clear them and earn points.</p>
          </div>
          
          <div className="flex gap-3 items-start">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-cyan-500/30 to-purple-500/30 flex items-center justify-center text-cyan-400 font-bold shrink-0 text-sm border border-cyan-500/30">2</div>
            <p><strong className="text-white">Swap tokens</strong> by clicking one token, then clicking an adjacent token to swap their positions.</p>
          </div>
          
          <div className="flex gap-3 items-start">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-cyan-500/30 to-purple-500/30 flex items-center justify-center text-cyan-400 font-bold shrink-0 text-sm border border-cyan-500/30">3</div>
            <p><strong className="text-white">Build combos</strong> - chain reactions earn multiplied points! Watch for cascading matches.</p>
          </div>
          
          <div className="flex gap-3 items-start">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-cyan-500/30 to-purple-500/30 flex items-center justify-center text-cyan-400 font-bold shrink-0 text-sm border border-cyan-500/30">4</div>
            <p><strong className="text-white">Reach the target score</strong> before running out of moves to complete each level and unlock more!</p>
          </div>
        </div>

        <div className="mt-5 p-3 bg-gray-800/50 rounded-xl">
          <div className="text-xs text-gray-400 mb-2">Token Values:</div>
          <div className="flex justify-center gap-1">
            {(['BTC', 'ETH', 'DOGE', 'SOL', 'ADA', 'XRP'] as const).map(type => (
              <div key={type} className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
                style={{ background: `linear-gradient(135deg, ${CRYPTO_CONFIG[type].color}ee, ${CRYPTO_CONFIG[type].color}88)`, color: type === 'ADA' || type === 'XRP' ? '#fff' : '#1a1a2e' }}>
                {CRYPTO_CONFIG[type].symbol}
              </div>
            ))}
          </div>
        </div>

        <button onClick={handleClose} className="w-full mt-5 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-xl font-bold text-white hover:opacity-90 transition active:scale-98">
          Let's Play!
        </button>
      </div>
    </div>
  );
};

export default HowToPlay;
