import React from 'react';
import { CRYPTO_CONFIG, CRYPTO_TYPES } from '@/constants/cryptos';

const GameFooter: React.FC = () => {
  return (
    <footer className="bg-gray-900/80 backdrop-blur-sm border-t border-cyan-500/20 mt-8">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 mb-3">
              CryptoCrush
            </h3>
            <p className="text-gray-400 text-sm">
              Match your favorite cryptocurrencies in this addictive puzzle game. Build combos, climb levels, and moon your score!
            </p>
          </div>
          
          <div>
            <h4 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-3">Featured Cryptos</h4>
            <div className="flex flex-wrap gap-2">
              {CRYPTO_TYPES.map(type => (
                <span 
                  key={type}
                  className="px-2 py-1 rounded text-xs font-medium"
                  style={{ 
                    backgroundColor: CRYPTO_CONFIG[type].color + '30',
                    color: CRYPTO_CONFIG[type].color,
                    border: `1px solid ${CRYPTO_CONFIG[type].color}50`
                  }}
                >
                  {CRYPTO_CONFIG[type].name}
                </span>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-3">Game Tips</h4>
            <ul className="text-gray-400 text-sm space-y-1">
              <li>• Look for chain reactions</li>
              <li>• Build combos for bonus points</li>
              <li>• Plan your moves wisely</li>
              <li>• Match 4+ for special effects</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-800 text-center text-gray-500 text-xs">
          <p>CryptoCrush is a fan-made game. Not affiliated with any cryptocurrency.</p>
          <p className="mt-1">Made with React & Tailwind CSS</p>
        </div>
      </div>
    </footer>
  );
};

export default GameFooter;
