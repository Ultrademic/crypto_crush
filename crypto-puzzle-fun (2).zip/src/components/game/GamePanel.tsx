import React from 'react';
import { GameState } from '@/types/game';
import { LEVELS } from '@/constants/cryptos';
import { useSound } from '@/contexts/SoundContext';

interface Props {
  gameState: GameState;
  onNewGame: () => void;
  onLevelSelect: () => void;
}

const TrophyIcon = () => (
  <svg className="w-5 h-5 inline mr-1" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 2C13.1 2 14 2.9 14 4V5H16C17.1 5 18 5.9 18 7V9C18 10.66 16.66 12 15 12H14.82C14.4 14.16 12.86 15.93 10.82 16.66L11 20H13C13.55 20 14 20.45 14 21V22H10V21C10 20.45 10.45 20 11 20H9L9.18 16.66C7.14 15.93 5.6 14.16 5.18 12H5C3.34 12 2 10.66 2 9V7C2 5.9 2.9 5 4 5H6V4C6 2.9 6.9 2 8 2H12Z"/>
  </svg>
);

const GamePanel: React.FC<Props> = ({ gameState, onNewGame, onLevelSelect }) => {
  const level = LEVELS[gameState.level - 1];
  const progress = Math.min((gameState.score / level.targetScore) * 100, 100);
  const { playClick } = useSound();

  const handleNewGame = () => {
    playClick();
    onNewGame();
  };

  const handleLevelSelect = () => {
    playClick();
    onLevelSelect();
  };

  return (
    <div className="bg-gray-900/90 backdrop-blur-sm rounded-2xl p-5 border border-cyan-500/30 shadow-xl w-full max-w-xs">
      <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 mb-4">
        Level {gameState.level}: {level.name}
      </h2>
      
      <div className="space-y-3">
        <div>
          <div className="flex justify-between text-xs text-gray-400 mb-1">
            <span>Target: {level.targetScore.toLocaleString()}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="h-3 bg-gray-800 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 transition-all duration-500 ease-out" style={{ width: `${progress}%` }} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gray-800/50 rounded-xl p-3 text-center border border-yellow-500/20">
            <div className="text-2xl font-bold text-yellow-400">{gameState.score.toLocaleString()}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wider">Score</div>
          </div>
          <div className="bg-gray-800/50 rounded-xl p-3 text-center border border-cyan-500/20">
            <div className={`text-2xl font-bold ${gameState.moves <= 5 ? 'text-red-400 animate-pulse' : 'text-cyan-400'}`}>{gameState.moves}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wider">Moves</div>
          </div>
        </div>

        {gameState.combo > 1 && (
          <div className="text-center py-2 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-lg border border-orange-500/30">
            <span className="text-xl font-bold text-orange-400">{gameState.combo}x COMBO!</span>
          </div>
        )}

        <div className="bg-gray-800/50 rounded-xl p-3 text-center border border-purple-500/20">
          <div className="text-lg font-bold text-purple-400"><TrophyIcon />{gameState.highScore.toLocaleString()}</div>
          <div className="text-xs text-gray-400 uppercase tracking-wider">Best Score</div>
        </div>

        <div className="flex gap-2 pt-2">
          <button onClick={handleNewGame} className="flex-1 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl font-bold text-white text-sm hover:opacity-90 transition active:scale-95">
            Restart
          </button>
          <button onClick={handleLevelSelect} className="flex-1 py-2.5 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl font-bold text-white text-sm hover:opacity-90 transition active:scale-95">
            Levels
          </button>
        </div>
      </div>
    </div>
  );
};

export default GamePanel;
