import React, { useEffect, useState } from 'react';

interface Props {
  score: number;
  combo: number;
}

interface Popup {
  id: number;
  points: number;
  combo: number;
}

const ScorePopup: React.FC<Props> = ({ score, combo }) => {
  const [popups, setPopups] = useState<Popup[]>([]);
  const [lastScore, setLastScore] = useState(score);

  useEffect(() => {
    if (score > lastScore) {
      const points = score - lastScore;
      const newPopup: Popup = {
        id: Date.now(),
        points,
        combo: combo > 1 ? combo - 1 : 1,
      };
      setPopups(prev => [...prev, newPopup]);
      setTimeout(() => {
        setPopups(prev => prev.filter(p => p.id !== newPopup.id));
      }, 1500);
    }
    setLastScore(score);
  }, [score, combo, lastScore]);

  return (
    <div className="fixed inset-0 pointer-events-none z-30 flex items-center justify-center">
      {popups.map(popup => (
        <div
          key={popup.id}
          className="absolute animate-bounce text-center"
          style={{
            animation: 'floatUp 1.5s ease-out forwards',
          }}
        >
          <div className="text-3xl font-black text-yellow-400 drop-shadow-lg">
            +{popup.points.toLocaleString()}
          </div>
          {popup.combo > 1 && (
            <div className="text-lg font-bold text-orange-400">
              {popup.combo}x Combo!
            </div>
          )}
        </div>
      ))}
      <style>{`
        @keyframes floatUp {
          0% { opacity: 1; transform: translateY(0) scale(1); }
          100% { opacity: 0; transform: translateY(-100px) scale(1.5); }
        }
      `}</style>
    </div>
  );
};

export default ScorePopup;
