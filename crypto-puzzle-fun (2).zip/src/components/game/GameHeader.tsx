import React from 'react';
import { useSound } from '@/contexts/SoundContext';

interface Props {
  onHowToPlay: () => void;
}

const BitcoinIcon = () => (
  <svg className="w-8 h-8 md:w-10 md:h-10 inline-block text-yellow-500 animate-bounce" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2v-1.93c-1.34-.23-2.5-.83-3.28-1.61l1.37-1.37c.6.6 1.43.96 2.41.96 1.38 0 2.5-.84 2.5-1.88 0-1.04-.9-1.62-2.5-2.12-2.3-.72-4-1.63-4-3.88 0-1.75 1.34-3.17 3.5-3.52V4h2v1.65c1.12.23 2.08.73 2.78 1.43l-1.37 1.37c-.5-.5-1.18-.8-1.91-.8-1.38 0-2.5.84-2.5 1.88 0 1.04.9 1.62 2.5 2.12 2.3.72 4 1.63 4 3.88 0 1.75-1.34 3.17-3.5 3.52z"/>
  </svg>
);

const SpeakerOnIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
  </svg>
);

const SpeakerOffIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
  </svg>
);

const GameHeader: React.FC<Props> = ({ onHowToPlay }) => {
  const { isMuted, toggleMute } = useSound();

  return (
    <div className="relative text-center py-6">
      {/* Watermark */}
      <div className="absolute top-2 right-2 md:top-4 md:right-4 text-xs md:text-sm text-gray-500/70 font-medium">
        Made by @Ultrademic
      </div>
      
      {/* Sound Toggle Button */}
      <button
        onClick={toggleMute}
        className="absolute top-2 left-2 md:top-4 md:left-4 p-2 bg-gray-800/60 hover:bg-gray-700/60 rounded-lg text-cyan-400 border border-cyan-500/40 transition-all hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-500/20"
        title={isMuted ? 'Unmute sounds' : 'Mute sounds'}
      >
        {isMuted ? <SpeakerOffIcon /> : <SpeakerOnIcon />}
      </button>
      
      <div className="flex items-center justify-center gap-2 mb-2">
        <BitcoinIcon />
        <h1 className="text-4xl md:text-5xl font-extrabold">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 drop-shadow-lg">
            Crypto
          </span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 drop-shadow-lg">
            Crush
          </span>
        </h1>
        <BitcoinIcon />
      </div>
      <p className="text-gray-400 text-sm md:text-base mb-4">
        Match crypto tokens • Build combos • Moon your score!
      </p>
      <button
        onClick={onHowToPlay}
        className="px-5 py-2 text-sm bg-gray-800/60 hover:bg-gray-700/60 rounded-lg text-cyan-400 border border-cyan-500/40 transition-all hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-500/20"
      >
        <svg className="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        How to Play
      </button>
    </div>
  );
};

export default GameHeader;

