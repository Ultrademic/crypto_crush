import React from 'react';
import { LEVELS } from '@/constants/cryptos';
import { useSound } from '@/contexts/SoundContext';

interface Props {
  currentLevel: number;
  highScore: number;
  onSelectLevel: (level: number) => void;
  onClose: () => void;
}

const LockIcon = () => (
  <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
  </svg>
);

const StarIcon = () => (
  <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
  </svg>
);

const LevelSelect: React.FC<Props> = ({ currentLevel, highScore, onSelectLevel, onClose }) => {
  const { playClick } = useSound();

  const handleSelectLevel = (levelId: number) => {
    playClick();
    onSelectLevel(levelId);
  };

  const handleClose = () => {
    playClick();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={handleClose}>
      <div className="bg-gray-900 rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto border border-cyan-500/30 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
            Select Level
          </h2>
          <button onClick={handleClose} className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center text-gray-400 hover:text-white transition">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
          {LEVELS.map((level) => {
            const unlocked = level.id <= Math.max(currentLevel, 1);
            const completed = level.id < currentLevel;
            return (
              <button key={level.id} onClick={() => unlocked && handleSelectLevel(level.id)} disabled={!unlocked}
                className={`p-3 rounded-xl text-center transition-all relative ${unlocked ? 'bg-gradient-to-br from-gray-800 to-gray-700 hover:from-cyan-900/50 hover:to-purple-900/50 border border-cyan-500/30 hover:border-cyan-400/50' : 'bg-gray-800/30 cursor-not-allowed border border-gray-700/30'}`}>
                {completed && <div className="absolute -top-1 -right-1"><StarIcon /></div>}
                <div className={`text-2xl font-bold mb-1 ${unlocked ? 'text-white' : 'text-gray-600'}`}>
                  {unlocked ? level.id : <LockIcon />}
                </div>
                <div className={`text-xs truncate ${unlocked ? 'text-gray-400' : 'text-gray-600'}`}>{level.name}</div>
                <div className={`text-xs mt-1 ${unlocked ? 'text-cyan-400' : 'text-gray-600'}`}>{level.targetScore.toLocaleString()} pts</div>
                <div className="text-xs text-gray-500 mt-0.5">{level.moves} moves</div>
              </button>
            );
          })}
        </div>
        
        <div className="mt-6 text-center text-gray-500 text-sm">
          Complete levels to unlock more challenges!
        </div>
      </div>
    </div>
  );
};

export default LevelSelect;
