import React, { useState, useEffect } from 'react';
import { TICKER_DATA } from '@/constants/cryptos';
import { TickerItem } from '@/types/game';

const TickerWall: React.FC = () => {
  const [tickers, setTickers] = useState<TickerItem[]>(TICKER_DATA);

  useEffect(() => {
    const interval = setInterval(() => {
      setTickers(prev => prev.map(t => ({
        ...t,
        price: t.price * (1 + (Math.random() - 0.5) * 0.002),
        change: t.change + (Math.random() - 0.5) * 0.5,
      })));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const duplicatedTickers = [...tickers, ...tickers, ...tickers];

  return (
    <div className="w-full bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 border-b border-cyan-500/30 overflow-hidden">
      <div className="flex animate-scroll whitespace-nowrap py-2">
        {duplicatedTickers.map((ticker, i) => (
          <div key={i} className="flex items-center mx-6 text-sm">
            <span className="font-bold text-white mr-2">{ticker.symbol}</span>
            <span className="text-gray-300 mr-2">
              ${ticker.price < 1 ? ticker.price.toFixed(4) : ticker.price.toFixed(2)}
            </span>
            <span className={ticker.change >= 0 ? 'text-green-400' : 'text-red-400'}>
              {ticker.change >= 0 ? '▲' : '▼'} {Math.abs(ticker.change).toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
      <style>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.33%); }
        }
        .animate-scroll { animation: scroll 20s linear infinite; }
      `}</style>
    </div>
  );
};

export default TickerWall;
