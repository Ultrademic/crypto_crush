import React, { useEffect, useState } from 'react';

interface Particle {
  id: number;
  x: number;
  y: number;
  color: string;
  size: number;
  vx: number;
  vy: number;
}

interface Props {
  trigger: number;
  color?: string;
}

const ParticleEffect: React.FC<Props> = ({ trigger, color = '#00ffff' }) => {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    if (trigger > 0) {
      const newParticles: Particle[] = Array.from({ length: 12 }, (_, i) => ({
        id: Date.now() + i,
        x: 50 + Math.random() * 20 - 10,
        y: 50 + Math.random() * 20 - 10,
        color: ['#F7931A', '#627EEA', '#C2A633', '#00FFA3', '#3366FF', '#00AAE4'][Math.floor(Math.random() * 6)],
        size: 4 + Math.random() * 8,
        vx: (Math.random() - 0.5) * 10,
        vy: (Math.random() - 0.5) * 10,
      }));
      setParticles(newParticles);
      setTimeout(() => setParticles([]), 1000);
    }
  }, [trigger]);

  if (particles.length === 0) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-30 overflow-hidden">
      {particles.map(p => (
        <div
          key={p.id}
          className="absolute rounded-full animate-ping"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            transform: `translate(${p.vx * 20}px, ${p.vy * 20}px)`,
            opacity: 0.8,
            boxShadow: `0 0 10px ${p.color}`,
          }}
        />
      ))}
    </div>
  );
};

export default ParticleEffect;
