import React from 'react';
import { Token } from '@/types/game';
import { CRYPTO_CONFIG } from '@/constants/cryptos';

interface Props {
  token: Token;
  isSelected: boolean;
  onClick: () => void;
  size: number;
}

const CryptoToken: React.FC<Props> = ({ token, isSelected, onClick, size }) => {
  const config = CRYPTO_CONFIG[token.type];
  
  return (
    <button
      onClick={onClick}
      className={`
        absolute rounded-xl flex items-center justify-center font-bold
        transition-all duration-200 transform cursor-pointer
        ${isSelected ? 'scale-110 z-10 ring-2 ring-white' : 'hover:scale-105'}
        ${token.isMatched ? 'scale-0 opacity-0' : ''}
      `}
      style={{
        width: size - 4,
        height: size - 4,
        left: token.col * size + 2,
        top: token.row * size + 2,
        background: `linear-gradient(135deg, ${config.color}ee, ${config.color}99)`,
        boxShadow: isSelected 
          ? `0 0 20px ${config.glow}, 0 0 40px ${config.glow}60`
          : `0 0 12px ${config.glow}40, inset 0 2px 4px rgba(255,255,255,0.25)`,
        border: `2px solid ${isSelected ? 'white' : config.glow + '90'}`,
        fontSize: size * 0.38,
        color: token.type === 'ADA' || token.type === 'XRP' ? '#fff' : '#1a1a2e',
        textShadow: token.type === 'ADA' || token.type === 'XRP' ? '0 1px 2px rgba(0,0,0,0.5)' : 'none',
      }}
    >
      <span className="font-extrabold">{config.symbol}</span>
    </button>
  );
};

export default CryptoToken;
