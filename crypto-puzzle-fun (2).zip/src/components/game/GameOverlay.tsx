import React, { useEffect } from 'react';
import { GameState } from '@/types/game';
import { LEVELS } from '@/constants/cryptos';
import { useSound } from '@/contexts/SoundContext';

interface Props {
  gameState: GameState;
  onNewGame: () => void;
  onNextLevel: () => void;
}

const TrophyIcon = () => (
  <svg className="w-16 h-16 mx-auto text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 2C13.1 2 14 2.9 14 4V5H16C17.1 5 18 5.9 18 7V9C18 10.66 16.66 12 15 12H14.82C14.4 14.16 12.86 15.93 10.82 16.66L11 20H13C13.55 20 14 20.45 14 21V22H10V21C10 20.45 10.45 20 11 20H9L9.18 16.66C7.14 15.93 5.6 14.16 5.18 12H5C3.34 12 2 10.66 2 9V7C2 5.9 2.9 5 4 5H6V4C6 2.9 6.9 2 8 2H12ZM4 7V9C4 9.55 4.45 10 5 10H5.09C5.03 9.67 5 9.34 5 9V7H4ZM15 10C15.55 10 16 9.55 16 9V7H15V9C15 9.34 14.97 9.67 14.91 10H15Z"/>
  </svg>
);

const GameOverIcon = () => (
  <svg className="w-16 h-16 mx-auto text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const GameOverlay: React.FC<Props> = ({ gameState, onNewGame, onNextLevel }) => {
  const { playLevelComplete, playGameOver, playClick } = useSound();
  
  useEffect(() => {
    if (gameState.levelComplete) {
      playLevelComplete();
    } else if (gameState.gameOver) {
      playGameOver();
    }
  }, [gameState.levelComplete, gameState.gameOver, playLevelComplete, playGameOver]);

  if (!gameState.gameOver && !gameState.levelComplete) return null;

  const isWin = gameState.levelComplete;
  const hasNextLevel = gameState.level < LEVELS.length;

  const handleNewGame = () => {
    playClick();
    onNewGame();
  };

  const handleNextLevel = () => {
    playClick();
    onNextLevel();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`bg-gray-900 rounded-2xl p-8 max-w-md w-full text-center border-2 ${isWin ? 'border-green-500' : 'border-red-500'}`}>
        <div className={`mb-4 ${isWin ? 'animate-bounce' : ''}`}>
          {isWin ? <TrophyIcon /> : <GameOverIcon />}
        </div>
        
        <h2 className={`text-3xl font-bold mb-2 ${isWin ? 'text-green-400' : 'text-red-400'}`}>
          {isWin ? 'Level Complete!' : 'Game Over'}
        </h2>
        
        <p className="text-gray-400 mb-6">
          {isWin ? `Amazing! You scored ${gameState.score.toLocaleString()} points!` : `You scored ${gameState.score.toLocaleString()} points. Try again!`}
        </p>

        <div className="bg-gray-800/50 rounded-xl p-4 mb-6">
          <div className="text-2xl font-bold text-yellow-400">{gameState.score.toLocaleString()}</div>
          <div className="text-xs text-gray-400 uppercase tracking-wider">Final Score</div>
        </div>

        <div className="flex gap-3">
          <button onClick={handleNewGame} className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl font-bold text-white hover:opacity-90 transition">
            Play Again
          </button>
          {isWin && hasNextLevel && (
            <button onClick={handleNextLevel} className="flex-1 py-3 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl font-bold text-white hover:opacity-90 transition">
              Next Level
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default GameOverlay;
