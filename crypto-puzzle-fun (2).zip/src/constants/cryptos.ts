import { CryptoType, Level, TickerItem } from '@/types/game';

export const CRYPTO_CONFIG: Record<CryptoType, { name: string; color: string; glow: string; symbol: string }> = {
  BTC: { name: 'Bitcoin', color: '#F7931A', glow: '#F7931A', symbol: '₿' },
  ETH: { name: 'Ethereum', color: '#627EEA', glow: '#627EEA', symbol: 'Ξ' },
  DOGE: { name: 'Dogecoin', color: '#C2A633', glow: '#C2A633', symbol: 'Ð' },
  SOL: { name: 'Solana', color: '#00FFA3', glow: '#00FFA3', symbol: '◎' },
  ADA: { name: 'Cardano', color: '#0033AD', glow: '#3366FF', symbol: '₳' },
  XRP: { name: 'Ripple', color: '#23292F', glow: '#00AAE4', symbol: '✕' },
};

export const CRYPTO_TYPES: CryptoType[] = ['BTC', 'ETH', 'DOGE', 'SOL', 'ADA', 'XRP'];

export const LEVELS: Level[] = [
  { id: 1, name: 'Rookie Trader', targetScore: 1000, moves: 20, gridSize: 8 },
  { id: 2, name: 'Day Trader', targetScore: 2000, moves: 18, gridSize: 8 },
  { id: 3, name: 'Swing Trader', targetScore: 3500, moves: 18, gridSize: 8 },
  { id: 4, name: 'HODLer', targetScore: 5000, moves: 16, gridSize: 8 },
  { id: 5, name: 'Whale Watcher', targetScore: 7000, moves: 16, gridSize: 8 },
  { id: 6, name: 'Market Maker', targetScore: 10000, moves: 15, gridSize: 8 },
  { id: 7, name: 'DeFi Degen', targetScore: 13000, moves: 15, gridSize: 8 },
  { id: 8, name: 'NFT Flipper', targetScore: 16000, moves: 14, gridSize: 8 },
  { id: 9, name: 'Yield Farmer', targetScore: 20000, moves: 14, gridSize: 8 },
  { id: 10, name: 'DAO Governor', targetScore: 25000, moves: 12, gridSize: 8 },
  { id: 11, name: 'Protocol Dev', targetScore: 30000, moves: 12, gridSize: 8 },
  { id: 12, name: 'Satoshi', targetScore: 40000, moves: 10, gridSize: 8 },
];

export const TICKER_DATA: TickerItem[] = [
  { symbol: 'BTC', price: 97432.50, change: 2.34 },
  { symbol: 'ETH', price: 3642.18, change: -1.12 },
  { symbol: 'DOGE', price: 0.4123, change: 5.67 },
  { symbol: 'SOL', price: 234.89, change: 3.21 },
  { symbol: 'ADA', price: 1.08, change: -0.45 },
  { symbol: 'XRP', price: 2.34, change: 1.89 },
];
