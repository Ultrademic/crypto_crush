import { useCallback, useRef, useState, useEffect } from 'react';

export const useSoundEffects = () => {
  const [isMuted, setIsMuted] = useState(() => {
    return localStorage.getItem('cryptoCrushMuted') === 'true';
  });
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    localStorage.setItem('cryptoCrushMuted', isMuted.toString());
  }, [isMuted]);

  const getAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioContextRef.current;
  }, []);

  const playTone = useCallback((freq: number, duration: number, type: OscillatorType = 'sine', vol = 0.3) => {
    if (isMuted) return;
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(vol, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration);
  }, [isMuted, getAudioContext]);

  const playMatch = useCallback(() => {
    playTone(523, 0.1, 'sine', 0.2);
    setTimeout(() => playTone(659, 0.1, 'sine', 0.2), 50);
    setTimeout(() => playTone(784, 0.15, 'sine', 0.25), 100);
  }, [playTone]);

  const playCombo = useCallback((combo: number) => {
    const baseFreq = 400 + (combo * 100);
    for (let i = 0; i < Math.min(combo, 5); i++) {
      setTimeout(() => playTone(baseFreq + (i * 80), 0.12, 'square', 0.15), i * 60);
    }
  }, [playTone]);

  const playLevelComplete = useCallback(() => {
    const notes = [523, 659, 784, 1047];
    notes.forEach((freq, i) => {
      setTimeout(() => playTone(freq, 0.3, 'sine', 0.25), i * 150);
    });
    setTimeout(() => {
      playTone(1047, 0.5, 'triangle', 0.3);
      playTone(784, 0.5, 'triangle', 0.2);
    }, 600);
  }, [playTone]);

  const playGameOver = useCallback(() => {
    const notes = [392, 349, 311, 262];
    notes.forEach((freq, i) => {
      setTimeout(() => playTone(freq, 0.25, 'sawtooth', 0.15), i * 200);
    });
  }, [playTone]);

  const playClick = useCallback(() => {
    playTone(800, 0.05, 'sine', 0.1);
  }, [playTone]);

  const toggleMute = useCallback(() => setIsMuted(prev => !prev), []);

  return { isMuted, toggleMute, playMatch, playCombo, playLevelComplete, playGameOver, playClick };
};
