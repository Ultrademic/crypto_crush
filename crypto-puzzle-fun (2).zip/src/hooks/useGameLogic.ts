import { useState, useCallback } from 'react';
import { Token, CryptoType, GameState, Position } from '@/types/game';
import { CRYPTO_TYPES, LEVELS } from '@/constants/cryptos';

const generateId = () => Math.random().toString(36).substr(2, 9);

const getRandomCrypto = (): CryptoType => CRYPTO_TYPES[Math.floor(Math.random() * CRYPTO_TYPES.length)];

export const useGameLogic = () => {
  const [gameState, setGameState] = useState<GameState>(() => ({
    board: [],
    score: 0,
    moves: LEVELS[0].moves,
    level: 1,
    combo: 1,
    isAnimating: false,
    gameOver: false,
    levelComplete: false,
    highScore: parseInt(localStorage.getItem('cryptoCrushHighScore') || '0'),
  }));

  const createBoard = useCallback((size: number): Token[][] => {
    const board: Token[][] = [];
    for (let row = 0; row < size; row++) {
      board[row] = [];
      for (let col = 0; col < size; col++) {
        let type = getRandomCrypto();
        while (
          (col >= 2 && board[row][col - 1]?.type === type && board[row][col - 2]?.type === type) ||
          (row >= 2 && board[row - 1]?.[col]?.type === type && board[row - 2]?.[col]?.type === type)
        ) {
          type = getRandomCrypto();
        }
        board[row][col] = { id: generateId(), type, row, col, isMatched: false };
      }
    }
    return board;
  }, []);

  const initGame = useCallback((levelId: number = 1) => {
    const level = LEVELS[levelId - 1];
    setGameState(prev => ({
      ...prev,
      board: createBoard(level.gridSize),
      score: 0,
      moves: level.moves,
      level: levelId,
      combo: 1,
      isAnimating: false,
      gameOver: false,
      levelComplete: false,
    }));
  }, [createBoard]);

  return { gameState, setGameState, initGame, createBoard };
};
