export type CryptoType = 'BTC' | 'ETH' | 'DOGE' | 'SOL' | 'ADA' | 'XRP';

export interface Token {
  id: string;
  type: CryptoType;
  row: number;
  col: number;
  isMatched: boolean;
  isSpecial?: 'rocket' | 'bomb';
}

export interface Position {
  row: number;
  col: number;
}

export interface Level {
  id: number;
  name: string;
  targetScore: number;
  moves: number;
  gridSize: number;
}

export interface GameState {
  board: Token[][];
  score: number;
  moves: number;
  level: number;
  combo: number;
  isAnimating: boolean;
  gameOver: boolean;
  levelComplete: boolean;
  highScore: number;
}

export interface TickerItem {
  symbol: string;
  price: number;
  change: number;
}
