import React, { createContext, useContext, ReactNode } from 'react';
import { useSoundEffects } from '@/hooks/useSoundEffects';

interface SoundContextType {
  isMuted: boolean;
  toggleMute: () => void;
  playMatch: () => void;
  playCombo: (combo: number) => void;
  playLevelComplete: () => void;
  playGameOver: () => void;
  playClick: () => void;
}

const SoundContext = createContext<SoundContextType | null>(null);

export const SoundProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const soundEffects = useSoundEffects();
  return <SoundContext.Provider value={soundEffects}>{children}</SoundContext.Provider>;
};

export const useSound = () => {
  const context = useContext(SoundContext);
  if (!context) throw new Error('useSound must be used within SoundProvider');
  return context;
};
